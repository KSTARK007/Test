class Point:
    def __init__(self, latit_, longit_):
        #self.id = id_   #an id which uniquely identifies a point
        self.latit = latit_
        self.longit = longit_
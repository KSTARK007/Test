note Please keep the data 
Run creatdata.py 
	Python createdata.py 1000000 > data.csv
Note dont create a dataset for more than a GB or else It will crash 
Run main.py 
	python main.py 
It prints the nodes 
